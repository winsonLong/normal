import cn.wonders.library.entity.User;
import cn.wonders.library.service.UserService;
import cn.wonders.library.service.ex.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestUserService {

    private AbstractApplicationContext ac;
    private UserService userService;

    @Before
    public void doBefore() {
        ac = new ClassPathXmlApplicationContext("spring-dao.xml", "spring-service.xml");
        userService = ac.getBean("userService", UserService.class);
    }

    @After
    public void doAfter() {
        ac.close();
    }

    @Test
    public void testRegManager(){
        try{
            User user = new User();
            user.setAccount("000000");
            user.setPassword("000000");
            user.setName("管理员");
            user.setGender(0);//0 表示男  1表示女
            user.setPhone("88888888");
            user.setEmail("guanliyuan@66.com");
            user.setIsManager(0);//0 表示是管理员
            User result = userService.reg(user);
            System.out.println(result);
        }catch (AccountConflictException e){
            System.out.println(e.getMessage());
        }catch (InsertDataException e){
            System.out.println(e.getMessage());
        }

    }

    @Test
    public void testReg(){
        try{
            User user = new User();
            user.setAccount("111111");
            user.setPassword("111111");
            user.setName("小明");
            user.setGender(0);//0 表示男  1表示女
            user.setPhone("13477889911");
            user.setEmail("xiaoming@11.com");
            user.setIsManager(1);//1 表示不是管理员
            User result = userService.reg(user);
            System.out.println(result);
        }catch (AccountConflictException e){
            System.out.println(e.getMessage());
        }catch (InsertDataException e){
            System.out.println(e.getMessage());
        }

    }

    @Test
    public void testLogin(){
        try {
            String account = "111111";
            String password = "111111";
            User user = userService.login(account,password);
            System.out.println("登录成功"+user);
        }catch (UserNotFoundException e){
            System.out.println(e.getMessage());
        }catch (PasswordNotMatchException e){
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void testChangePasswordByOldPassword(){
        try{
            Integer uid = 4;
            String oldPassword = "000000";
            String newPassword = "111111";
            userService.changePasswordByOldPassword(uid,oldPassword,newPassword);
            System.out.println("修改成功");
        }catch (UserNotFoundException e){
            System.out.println(e.getMessage());
        }catch (PasswordNotMatchException e){
            System.out.println(e.getMessage());
        }catch (UpdateDataException e){
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void testChangeInfo(){
        try{
            User user = new User();
            user.setId(4);
            user.setEmail("222@22.com");
            userService.changeInfo(user);
            System.out.println("修改成功");
        }catch (UpdateDataException e){
            System.out.println(e.getMessage());
        }catch (UserNotFoundException e){
            System.out.println(e.getMessage());
        }

    }

}
