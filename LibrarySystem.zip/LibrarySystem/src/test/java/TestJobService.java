import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestJobService {

    public static void main(String[] args){
        new ClassPathXmlApplicationContext("spring-task.xml");
    }
}
