import cn.wonders.library.entity.Book;
import cn.wonders.library.service.BookService;
import cn.wonders.library.service.UserService;
import cn.wonders.library.service.ex.InsertDataException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class TestBookService {

    private AbstractApplicationContext ac;
    private BookService bookService;

    @Before
    public void doBefore() {
        ac = new ClassPathXmlApplicationContext("spring-dao.xml", "spring-service.xml");
        bookService = ac.getBean("bookService", BookService.class);
    }

    @After
    public void doAfter() {
        ac.close();
    }

    @Test
    public void testAddBook(){
        try{
            Book book = new Book();
            book.setNumber("037");
            book.setBookName("疯狂Java讲义");
            book.setAuthor("李刚");
            book.setType(11);
            book.setPrice(54.5);
            book.setAmount(5);
            bookService.addBook(book);
            System.out.println("新增图书成功"+book);
        }catch (InsertDataException e){
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void testDelete(){
        String number = "037";
        bookService.delete(number);
        System.out.println("删除成功");
    }

    @Test
    public void testGetListByType(){
        List<Book> books = bookService.getListByType(1,1);
        System.out.println(books);
    }

    @Test
    public void testGetBookByBookName(){
        String bookName = "";
        Integer page = 2;
        List<Book> books =  bookService.getBookByBookName(bookName,page);
        System.out.println(books);
    }
}
