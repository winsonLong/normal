import org.apache.commons.dbcp.BasicDataSource;
import org.junit.Test;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.Connection;

import java.sql.SQLException;

public class TestConnection {

    @Test
    public void testConn() throws SQLException {
        AbstractApplicationContext acc = new ClassPathXmlApplicationContext("spring-dao.xml");
        BasicDataSource dataSource = acc.getBean("ds",BasicDataSource.class);
        Connection conn = dataSource.getConnection();
        System.out.println(conn);
        acc.close();
    }
}
