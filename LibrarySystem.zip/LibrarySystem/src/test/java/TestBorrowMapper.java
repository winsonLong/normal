import cn.wonders.library.mapper.BorrowMapper;
import cn.wonders.library.vo.BorrowVO;
import cn.wonders.library.vo.EmailVO;
import cn.wonders.library.vo.ReturnVO;
import cn.wonders.library.vo.WarnVO;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class TestBorrowMapper {

    private AbstractApplicationContext ac;
    private BorrowMapper borrowMapper;

    @Before
    public void doBefore() {
        ac = new ClassPathXmlApplicationContext(
                "spring-dao.xml");
        borrowMapper = ac.getBean(
                "borrowMapper", BorrowMapper.class);
    }

    @After
    public void doAfter() {
        ac.close();
    }

    @Test
    public void testGetBorrowByUid(){
        Integer uid = 4;
        Integer offset = 0;
        Integer count = 4;
        List<BorrowVO> borrowVOs = borrowMapper.getBorrowByUid(uid,offset,count);
        for(BorrowVO b : borrowVOs){
            System.out.println(b);
        }
    }

    @Test
    public void testGetWarnList(){
        List<WarnVO> warnVOS = borrowMapper.getWarnList();
        for(WarnVO w : warnVOS){
            System.out.println(w);
        }
    }

    @Test
    public void testGetEmail(){
        List<EmailVO> borrowVOs = borrowMapper.getEmail();
        for(EmailVO b : borrowVOs){
            System.out.println(b);
        }
    }

    @Test
    public void testGetBorrowingListByAccount(){
        String account = "111111";
        List<ReturnVO> returnVOS = borrowMapper.getBorrowingListByAccount(account);
        for(ReturnVO r : returnVOS){
            System.out.println(r);
        }
    }

    @Test
    public void testUpdateStatusAndActuDate(){
        Integer uid = 4;
        String bid = "4001";
        Integer rows = borrowMapper.updateStatusAndActuDate(uid,bid);
        System.out.println("rows:"+rows);
    }
}
