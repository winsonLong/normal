import cn.wonders.library.entity.Borrow;
import cn.wonders.library.service.BorrowService;
import cn.wonders.library.service.ex.BorrowingCountOutException;
import cn.wonders.library.service.ex.InsertDataException;
import cn.wonders.library.service.ex.RepeatBorrowingException;
import cn.wonders.library.service.ex.UderstockException;
import cn.wonders.library.vo.BorrowingVO;
import cn.wonders.library.vo.EmailVO;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class TestBorrowService {

    private AbstractApplicationContext ac;
    private BorrowService borrowService;

    @Before
    public void doBefore() {
        ac = new ClassPathXmlApplicationContext("spring-dao.xml", "spring-service.xml");
        borrowService = ac.getBean("borrowService", BorrowService.class);
    }

    @After
    public void doAfter() {
        ac.close();
    }

    @Test
    public void testAddBorrow(){
        try{
            Borrow borrow = new Borrow();
            borrow.setUid(4);
            borrow.setBid("1001");
            borrowService.addBorrow(borrow);
            System.out.println("借阅成功啦");
        }catch(RepeatBorrowingException e){
            System.out.println(e.getMessage());
        }catch(UderstockException e){
            System.out.println(e.getMessage());
        }catch(BorrowingCountOutException e){
            System.out.println(e.getMessage());
        }catch(InsertDataException e){
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void testGetBorrowingByUid(){
        Integer uid = 4;
        Integer page = 2;
        List<BorrowingVO> borrowingVOS = borrowService.getBorrowingByUid(uid,page);
        for(BorrowingVO b : borrowingVOS){
            System.out.println(b);
        }
    }



}
