import cn.wonders.library.entity.User;
import cn.wonders.library.mapper.UserMapper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class TestUserMapper {

    private AbstractApplicationContext ac;
    private UserMapper userMapper;

    @Before
    public void doBefore() {
        ac = new ClassPathXmlApplicationContext(
                "spring-dao.xml");
        userMapper = ac.getBean(
                "userMapper", UserMapper.class);
    }

    @After
    public void doAfter() {
        ac.close();
    }

    @Test
    public void changeInfo() {
        User user = new User();
        user.setId(4);
        user.setPhone("111");
        user.setIsManager(1);

        Integer rows = userMapper.changeInfo(user);
        System.out.println("rows=" + rows);
    }

    @Test
    public void testAddBorrowCount(){
        Integer uid = 4;
        Integer rows = userMapper.addBorrowCount(uid);
        System.out.println("rows:"+rows);
    }

    @Test
    public void testListUser(){
        List<User> users =  userMapper.getUserList();
        System.out.println(users);
    }
}
