/*1.对用户名进行验证*/
account.onblur = function(){
    if(this.validity.valueMissing){
        this.nextElementSibling.innerHTML = '账号不能为空';
        this.nextElementSibling.className = 'msg-error';
        this.setCustomValidity('账号不能为空');
    }else if(this.validity.tooShort){
        this.nextElementSibling.innerHTML = '账号不能少于6位';
        this.nextElementSibling.className = 'msg-error';
        this.setCustomValidity('账号不能少于6位');
    }else {
        this.nextElementSibling.innerHTML = '账号格式正确';
        this.nextElementSibling.className = 'msg-success';
        this.setCustomValidity('');
        var data =document.getElementById("account").value;
        if(!data){   //用户没有输入任何内容
            return;
        }
        /**发起异步GET请求，询问服务器用户名是否已经存在**/
            //1 创建xhr
        var xhr = new XMLHttpRequest();
        console.log(xhr);
        //2 监听状态改变 01234，4最有价值
        xhr.onreadystatechange = function(){
            if(xhr.readyState===4){//响应完成
                if(xhr.status===200){
                    console.log('响应完成且成功');
                    doResponse(xhr);
                }
                else {
                    console.log('响应完成但有问题');
                }
            }
        }
        //3 打开连接
        /* xhr.open('GET','/checkUsername.html?username='+data, true);
         //4 发送请求
         xhr.send(null);*/

        //处理响应消息
        function doResponse(xhr){
            console.log('开始处理响应数据');
            //console.log(xhr);
            if(xhr.responseText==='yes'){
                alert('该用户名已被占用');
            }else if(xhr.responseText==='no'){
                alert('该用户名可以使用');
            }else {
                alert(xhr.responseText);
            }
        }
    }
}

account.onfocus = function(){
    this.nextElementSibling.innerHTML = '账号长度在6到9位之间';
    this.nextElementSibling.className = 'msg-default';
}
password.onfocus = function(){
    this.nextElementSibling.innerHTML = '密码长度在6到12位之间';
    this.nextElementSibling.className = 'msg-default';
}
password.onblur = function(){
    if(this.validity.valueMissing){
        this.nextElementSibling.innerHTML = '密码不能为空';
        this.nextElementSibling.className = 'msg-error';
        this.setCustomValidity('密码不能为空');
    }else if(this.validity.tooShort){
        this.nextElementSibling.innerHTML = '密码长度在尽量别少于6位';
        this.nextElementSibling.className = 'msg-error';
        this.setCustomValidity('密码长度在尽量别少于6位');
    }else {
        this.nextElementSibling.innerHTML = '密码格式正确';
        this.nextElementSibling.className = 'msg-success';
        this.setCustomValidity('');
    }
}


upwdconfirm.onfocus = function(){
    this.nextElementSibling.innerHTML = '密码长度在6到12位之间';
    this.nextElementSibling.className = 'msg-default';
}
upwdconfirm.onblur = function(){
    if(this.validity.valueMissing){
        this.nextElementSibling.innerHTML = '密码不能为空';
        this.nextElementSibling.className = 'msg-error';
        this.setCustomValidity('密码不能为空');
    }else if(this.validity.tooShort){
        this.nextElementSibling.innerHTML = '密码长度在尽量别少于6位';
        this.nextElementSibling.className = 'msg-error';
        this.setCustomValidity('密码长度在尽量别少于6位');
    }else {
        this.nextElementSibling.innerHTML = '密码格式正确';
        this.nextElementSibling.className = 'msg-success';
        this.setCustomValidity('');
    }
}

/*3.对邮箱地址进行验证*/
email.onblur = function(){
    if(this.validity.valueMissing){
        this.nextElementSibling.innerHTML = '邮箱不能为空';
        this.nextElementSibling.className = 'msg-error';
        this.setCustomValidity('邮箱不能为空');
    }else if(this.validity.typeMismatch){
        this.nextElementSibling.innerHTML = '邮箱格式不正确';
        this.nextElementSibling.className = 'msg-error';
        this.setCustomValidity('邮箱格式不正确');
    }else {
        this.nextElementSibling.innerHTML = '邮箱格式正确';
        this.nextElementSibling.className = 'msg-success';
        this.setCustomValidity('');

        var data =document.getElementById("email").value;
        if(!data){   //用户没有输入任何内容
            return;
        }
        /**发起异步GET请求，询问服务器用户名是否已经存在**/
            //1 创建xhr
        var xhr = new XMLHttpRequest();
        //2 监听状态改变 01234，4最有价值
        xhr.onreadystatechange = function(){
            if(xhr.readyState===4){//响应完成
                if(xhr.status===200){
                    console.log('响应完成且成功');
                    doResponse(xhr);
                }
                else {
                    console.log('响应完成但有问题');
                }
            }
        }
        /*    //3 打开连接
            xhr.open('GET','/checkEmail.html?email='+data, true);
            //4 发送请求
            xhr.send(null);*/

        //处理响应消息
        function doResponse(xhr){
            console.log('开始处理响应数据');
            //console.log(xhr);
            if(xhr.responseText==='yes'){
                alert('该邮箱已被占用');
            }else if(xhr.responseText==='no'){
                alert('该邮箱可以使用');
            }else {
                alert(xhr.responseText);
            }
        }
    }
}
email.onfocus = function(){
    this.nextElementSibling.innerHTML = '请输入合法的邮箱地址';
    this.nextElementSibling.className = 'msg-default';
}
/*3.对手机号进行验证*/
phone.onblur = function(){
    if(this.validity.valueMissing){
        this.nextElementSibling.innerHTML = '手机号不能为空';
        this.nextElementSibling.className = 'msg-error';
        this.setCustomValidity('手机号不能为空');
    }else if(this.validity.patternMismatch){
        this.nextElementSibling.innerHTML = '手机号格式不正确';
        this.nextElementSibling.className = 'msg-error';
        this.setCustomValidity('手机号格式不正确');
    }else {
        this.nextElementSibling.innerHTML = '手机号格式正确';
        this.nextElementSibling.className = 'msg-success';
        this.setCustomValidity('');

        var data =document.getElementById("phone").value;
        if(!data){   //用户没有输入任何内容
            return;
        }
        /**发起异步GET请求，询问服务器用户名是否已经存在**/
            //1 创建xhr
        var xhr = new XMLHttpRequest();
        //2 监听状态改变 01234，4最有价值
        xhr.onreadystatechange = function(){
            if(xhr.readyState===4){//响应完成
                if(xhr.status===200){
                    console.log('响应完成且成功');
                    doResponse(xhr);
                }
                else{
                    console.log('响应完成但有问题');
                }
            }
        }
        //3 打开连接
        /*   xhr.open('GET','/checkPhone.html?phone='+data, true);
           //4 发送请求
           xhr.send(null);*/

        //处理响应消息
        function doResponse(xhr){
            console.log('开始处理响应数据');
            //console.log(xhr);
            if(xhr.responseText==='yes'){
                alert('该号码已被占用');
            }else if(xhr.responseText==='no'){
                alert('该号码可以使用');
            }else {
                alert(xhr.responseText);
            }
        }
    }
}
phone.onfocus = function(){
        this.nextElementSibling.innerHTML = '请输入合法的手机号';
        this.nextElementSibling.className = 'msg-default';
    }