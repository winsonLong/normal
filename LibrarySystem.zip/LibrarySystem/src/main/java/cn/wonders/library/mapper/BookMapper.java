package cn.wonders.library.mapper;

import cn.wonders.library.entity.Book;
import cn.wonders.library.vo.ReturnVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BookMapper {

    /**
     * 新增图书
     * @param book
     * @return
     */
    Integer insert(Book book);

    /**
     * 删除图书
     * @param number
     */
    Integer delete(String number);

    /**
     * 通过图书类别获取图书列表
     * @param type
     * @return
     */
    List<Book> getListByType(
            @Param("type") Integer type,
            @Param("offset") Integer offset,
            @Param("count") Integer count);

    /**
     * 根据类别查询图书的数量
     * @param type
     * @return
     */
    Integer getCountByType(Integer type);

    /**
     * 通过图书编号查找图书
     * @param number
     * @return
     */
    Book getBookByNumber(String number);

    /**
     * 通过书名查找图书
     * @param bookName
     * @return
     */
    List<Book> getBookByBookName(
            @Param("bookName") String bookName,
            @Param("offset") Integer offset,
            @Param("count") Integer count);

    /**
     * 获取模糊查询到的书籍的数量
     * @param bookName
     * @return
     */
    Integer getCountByBookName(String bookName);

    /**
     * 修改图书数量
     * @param number
     * @return
     */
    Integer changeBookAmount(
            @Param("amount") Integer amount,
            @Param("number") String number);


}
