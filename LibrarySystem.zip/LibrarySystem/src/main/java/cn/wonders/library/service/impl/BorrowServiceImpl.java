package cn.wonders.library.service.impl;

import cn.wonders.library.entity.Book;
import cn.wonders.library.entity.Borrow;
import cn.wonders.library.mapper.BookMapper;
import cn.wonders.library.mapper.BorrowMapper;
import cn.wonders.library.mapper.UserMapper;
import cn.wonders.library.service.BorrowService;
import cn.wonders.library.service.ex.*;
import cn.wonders.library.vo.BorrowVO;
import cn.wonders.library.vo.BorrowingVO;
import cn.wonders.library.vo.EmailVO;
import cn.wonders.library.vo.ReturnVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service("borrowService")
public class BorrowServiceImpl implements BorrowService {

    @Autowired
    private BorrowMapper borrowMapper;
    @Autowired
    private BookMapper bookMapper;
    @Autowired
    private UserMapper userMapper;

    @Override
    @Transactional
    public void addBorrow(Borrow borrow) throws InsertDataException,BorrowingCountOutException,UderstockException,RepeatBorrowingException,UpdateDataException{
        //获取用户已借阅未归还的书籍的数量
        Integer borrowing = getCountByUid(borrow.getUid());
        //如果未归还的数量小于10本，则可以继续借阅
        if(borrowing<10){
            //根据书的编号获取该书的库存数量
            Book result = bookMapper.getBookByNumber(borrow.getBid());
            //如果库存大于0，则可以借阅该本书
            Integer amount = result.getAmount();
            if(amount>0){
                //判断该用户是否已正在借阅该书籍
                Integer count = getCountByUidAndBid(borrow.getUid(),borrow.getBid());
                if(count==0){
                    //执行新增借阅书籍
                    insert(borrow);
                    //将用户信息的借阅数量加一
                    userMapper.addBorrowCount(borrow.getUid());
                    //将该书的库存数量减一
                    amount--;
                    Integer rows = bookMapper.changeBookAmount(amount,borrow.getBid());
                    if(rows!=1){
                        throw new UpdateDataException("修改库存数量错误");
                    }
                }else{
                    throw new RepeatBorrowingException("不能重复借阅该书籍");
                }
            }else{
                throw new UderstockException("库存不足，无法借阅");
            }
        }else{
            throw new BorrowingCountOutException("正在借阅数量超出范围");
        }
    }

    @Override
    public void insert(Borrow borrow) throws InsertDataException{
        // 为用户没有提交的属性设置值
        Calendar calendar = Calendar.getInstance();
        Date lentDate = calendar.getTime();
        calendar.add(Calendar.MONTH,1);
        Date returnDate = calendar.getTime();
        borrow.setLentDate(lentDate);
        borrow.setReturnDate(returnDate);
        borrow.setStatus(1);
        Integer rows = borrowMapper.insert(borrow);
        if(rows!=1){
            throw new InsertDataException("新增借阅书籍异常");
        }
    }

    @Override
    public Integer getCountByUid(Integer uid) {
        return borrowMapper.getCountByUid(uid);
    }

    @Override
    public Integer getCountByUidAndBid(Integer uid, String bid) {
        return borrowMapper.getCountByUidAndBid(uid,bid);
    }

    @Override
    public List<BorrowVO> getBorrowByUid(Integer uid, Integer page) {
        //如果page无效，视为page=1
        if(page==null || page<1) {
            page = 1;
        }
        Integer maxPage = getBorrowedMaxPage(uid);
        //如果page超出最大页数
        if(page>maxPage) {
            page = maxPage;
        }
        //执行查询
        Integer offset = (page-1)*COUNT_PER_PAGE;
        Integer count = COUNT_PER_PAGE;
        return borrowMapper.getBorrowByUid(uid,offset,count);
    }

    @Override
    public Integer getBorrowedMaxPage(Integer uid) {
        Integer dataCount = getCountBorrowed(uid);
        Integer maxPage = (int) Math.ceil(1. * dataCount / COUNT_PER_PAGE); // 总数据量，每页数据量
        return maxPage;
    }

    @Override
    public Integer getCountBorrowed(Integer uid) {
        return borrowMapper.getCountBorrowed(uid);
    }

    @Override
    public List<BorrowingVO> getBorrowingByUid(Integer uid, Integer page) {
        //如果page无效，视为page=1
        if(page==null || page<1) {
            page = 1;
        }
        Integer maxPage = getBorrowingMaxPage(uid);
        //如果page超出最大页数
        if(page>maxPage) {
            page = maxPage;
        }
        //执行查询
        Integer offset = (page-1)*COUNT_PER_PAGE;
        Integer count = COUNT_PER_PAGE;
        return borrowMapper.getBorrowingByUid(uid,offset,count);
    }

    @Override
    public Integer getBorrowingMaxPage(Integer uid) {
        Integer dataCount = getCountByUid(uid);
        Integer maxPage = (int) Math.ceil(1. * dataCount / COUNT_PER_PAGE); // 总数据量，每页数据量
        return maxPage;
    }

    @Override
    public List<EmailVO> getEmail() {
        return borrowMapper.getEmail();
    }

    @Override
    public List<ReturnVO> getBorrowingListByAccount(String account) {
        return borrowMapper.getBorrowingListByAccount(account);
    }

    @Override
    @Transactional
    public void retrunBook(Integer uid, String bid) throws UderstockException{
        Integer row1 = borrowMapper.updateStatusAndActuDate(uid,bid);
        if(row1!=1){
            throw new UpdateDataException("修改失败");
        }
        Book result = bookMapper.getBookByNumber(bid);
        Integer amount = result.getAmount();
        amount++;
        Integer row2 = bookMapper.changeBookAmount(amount,bid);
        if(row2!=1){
            throw new UpdateDataException("修改失败");
        }
        Integer row3 = userMapper.reduceBorrowCount(uid);
        if(row3!=1){
            throw new UpdateDataException("修改失败");
        }
    }
}
