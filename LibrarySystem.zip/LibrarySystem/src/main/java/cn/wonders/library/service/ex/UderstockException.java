package cn.wonders.library.service.ex;

public class UderstockException extends ServiceException {

    public UderstockException() {
    }

    public UderstockException(String message) {
        super(message);
    }

    public UderstockException(String message, Throwable cause) {
        super(message, cause);
    }

    public UderstockException(Throwable cause) {
        super(cause);
    }

    public UderstockException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
