package cn.wonders.library.mapper;

import cn.wonders.library.entity.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserMapper {

    /**
     * 新增用户
     * @param user 新增的用户的数据
     * @return 受影响的行数
     */
    Integer insert(User user);

    /**
     * 根据账号查询用户信息
     * @param account 账号
     * @return 与账号匹配的数据，如果没有匹配的数据，则返回null
     */
    User getUserByAccount(String account);

    /**
     * 根据用户id查询用户数据
     * @param uid 用户id
     * @return 与用户id匹配的数据，如果没有匹配的数据，则返回null
     */
    User getUserById(Integer uid);

    /**
     * 修改密码
     * @param uid 用户id
     * @param password 新密码
     * @return 受影响的行数
     */
    Integer changePassword(
            @Param("uid") Integer uid,
            @Param("password") String password);

    /**
     * 修改个人信息，包括：性别、头像、电话、邮箱
     * @param user 被修改的用户的新信息，至少包括用户id，可修改的数据包括：性别、头像、电话、邮箱
     * @return 受影响的行数
     */
    Integer changeInfo(User user);

    /**
     * 获取用户信息列表
     * @return
     */
    List<User> getUserList();

    /**
     * 增加用户的借阅数量
     * @param uid
     * @return
     */
    Integer addBorrowCount(Integer uid);

    /**
     * 减少用户的借阅数量
     * @param uid
     * @return
     */
    Integer reduceBorrowCount(Integer uid);
}
