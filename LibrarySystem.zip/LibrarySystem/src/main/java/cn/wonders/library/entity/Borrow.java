package cn.wonders.library.entity;

import java.util.Date;

public class Borrow {

    private Integer id;
    private Integer uid;
    private String bid;
    private Date lentDate;
    private Date returnDate;
    private Date actuDate;
    private Integer status;

    public Borrow() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getBid() {
        return bid;
    }

    public void setBid(String bid) {
        this.bid = bid;
    }

    public Date getLentDate() {
        return lentDate;
    }

    public void setLentDate(Date lentDate) {
        this.lentDate = lentDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public Date getActuDate() {
        return actuDate;
    }

    public void setActuDate(Date actuDate) {
        this.actuDate = actuDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Borrow{" +
                "id=" + id +
                ", uid=" + uid +
                ", bid='" + bid + '\'' +
                ", lentDate=" + lentDate +
                ", returnDate=" + returnDate +
                ", actuDate=" + actuDate +
                ", status=" + status +
                '}';
    }
}
