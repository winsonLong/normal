package cn.wonders.library.mapper;

import cn.wonders.library.entity.Borrow;
import cn.wonders.library.vo.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BorrowMapper {

    /**
     * 新增借阅的书籍
     * @param borrow
     * @return
     */
    Integer insert(Borrow borrow);

    /**
     * 获取uid用户正在借阅的bid书籍的数量
     * @param uid
     * @param bid
     * @return
     */
    Integer getCountByUidAndBid(
            @Param("uid") Integer uid,
            @Param("bid") String bid);

    /**
     * 根据用户id查询已借阅过的书籍列表
     * @param uid
     * @param offset
     * @param count
     * @return
     */
    List<BorrowVO> getBorrowByUid(
            @Param("uid") Integer uid,
            @Param("offset") Integer offset,
            @Param("count") Integer count);

    /**
     * 获取用户借阅已归还的书籍的数量
     * @param uid
     * @return
     */
    Integer getCountBorrowed(Integer uid);

    /**
     * 根据用户id查询正在借阅的书籍列表
     * @param uid
     * @param offset
     * @param count
     * @return
     */
    List<BorrowingVO> getBorrowingByUid(
            @Param("uid") Integer uid,
            @Param("offset") Integer offset,
            @Param("count") Integer count);

    /**
     * 获取uid用户已借阅未归还的书籍的数量
     * @param uid
     * @return
     */
    Integer getCountByUid(Integer uid);

    /**
     * 获取需要到期提醒的列表
     * @return
     */
    List<WarnVO> getWarnList();

    /**
     * 获取email
     * @return
     */
    List<EmailVO> getEmail();

    /**
     * 根据账号查询用户正在借阅的书籍
     * @param account
     * @return
     */
    List<ReturnVO> getBorrowingListByAccount(String account);

    /**
     * 根据uid和bid查询到借阅记录，修改状态为0,增加实际还书时间
     * @param uid
     * @param bid
     * @return
     */
    Integer updateStatusAndActuDate(
            @Param("uid") Integer uid,
            @Param("bid") String bid);
}
