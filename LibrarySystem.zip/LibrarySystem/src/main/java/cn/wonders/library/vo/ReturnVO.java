package cn.wonders.library.vo;

import java.util.Date;

public class ReturnVO {

    private Integer uid;
    private String bid;
    private Integer account;
    private String bookName;
    private Double price;
    private Date lentDate;
    private Date returnDate;

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getBid() {
        return bid;
    }

    public void setBid(String bid) {
        this.bid = bid;
    }

    public Integer getAccount() {
        return account;
    }

    public void setAccount(Integer account) {
        this.account = account;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Date getLentDate() {
        return lentDate;
    }

    public void setLentDate(Date lentDate) {
        this.lentDate = lentDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    @Override
    public String toString() {
        return "ReturnVO{" +
                "uid=" + uid +
                ", bid=" + bid +
                ", account=" + account +
                ", bookName='" + bookName + '\'' +
                ", price=" + price +
                ", lentDate=" + lentDate +
                ", returnDate=" + returnDate +
                '}';
    }
}
