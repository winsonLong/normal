package cn.wonders.library.mailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;

@Service
public class JobService {

    @Autowired
    private MyMail mail;
    @Scheduled(cron="0 0 9 * * ?")
    public void job1() throws MessagingException {
        System.out.println("开始发送");
        mail.send();
        System.out.println("发送成功");
    }

}
