package cn.wonders.library.mailService;

import cn.wonders.library.mapper.BorrowMapper;
import cn.wonders.library.vo.EmailVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Date;
import java.util.List;
import java.util.Properties;

@Service
public class MyMail {
    @Autowired
    private BorrowMapper borrowMapper;

    public   void  send () throws MessagingException {

        /**
         * 简单邮件发送实现
         *   发送邮件的过程类似于火箭送卫星上天
         */
        //装载数据
        Message message = null;
        Properties properties = new Properties();

        //邮箱服务器端的配置
        properties.put("mail.smtp.host","smtp.qq.com");//qq邮箱的主机域名地址
        //是否授权的设置
        properties.put("mail.smtp.auth", "true");
        //是否进行SSL认证加密的操作
        properties.put("mail.smtp.ssl.enable", true);
        //QQ邮箱的默认端口号
        properties.put("mail.smtp.port", 465);

        Session session = Session.getDefaultInstance(properties, new Authenticator() {

            //匿名内部方法
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                //准备邮箱账号和授权的密码
                return new  PasswordAuthentication("316531990@qq.com","ufolhxztxdrucbec");
            }
        });

        message = new MimeMessage(session);

        /**
         *设置邮件
         *   发送人
         *   接收人
         *   发送内容
         *   主题
         */
        //准备自己的发送地址
        Address from = new InternetAddress("316531990@qq.com");
        message.setFrom(from);

        List<EmailVO> emailVOs= borrowMapper.getEmail();


        Date s=new Date();
        //准备发送人的地址
        for (EmailVO VO:emailVOs ) {

            Address[] addresses = new InternetAddress[1];
           addresses[0] = new InternetAddress(VO.getEmail());
            // 设置邮件的主题
            message.setSubject("Wonders还书即将到期提醒");

            int day=(int)((VO.getReturnDate().getTime()-s.getTime())/60/60/24/1000)+1;
            //设置邮件的内容
            if(day>0) {
                System.out.println("尊敬的用户：" + VO.getName() + ",您借阅的图书《" + VO.getBookName() + "》还剩" +
                        day + "天，请规划好时间，尽快归还。谢谢！");
                message.setText("尊敬的用户：" + VO.getName() + ",您借阅的图书《" + VO.getBookName() + "》还剩" +
                        day + "天，请规划好时间，尽快归还。谢谢！");
            }else
            {
                day=Math.abs(day);
                message.setText("尊敬的用户：" + VO.getName() + ",您借阅的图书《" + VO.getBookName() + "》已经逾期" +
                        day + "天，请尽快归还，以免被封禁账号。谢谢！");
                System.out.println("尊敬的用户：" + VO.getName() + ",您借阅的图书《" + VO.getBookName() + "》已经逾期" +
                        day + "天，请尽快归还，以免被封禁账号。谢谢！");
            }

            //设置邮件的接收人
            message.setRecipients(Message.RecipientType.TO,addresses);
            Transport.send(message);

        }

        // 送卫星上天,发送邮件


    }
}

