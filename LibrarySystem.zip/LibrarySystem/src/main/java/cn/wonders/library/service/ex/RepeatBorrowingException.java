package cn.wonders.library.service.ex;

public class RepeatBorrowingException extends ServiceException {

    public RepeatBorrowingException() {
    }

    public RepeatBorrowingException(String message) {
        super(message);
    }

    public RepeatBorrowingException(String message, Throwable cause) {
        super(message, cause);
    }

    public RepeatBorrowingException(Throwable cause) {
        super(cause);
    }

    public RepeatBorrowingException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
