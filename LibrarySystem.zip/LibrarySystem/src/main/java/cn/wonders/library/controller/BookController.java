package cn.wonders.library.controller;

import cn.wonders.library.entity.Book;
import cn.wonders.library.entity.ResponseResult;
import cn.wonders.library.service.BookService;
import cn.wonders.library.service.ex.UploadAvatarException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/book")
public class BookController extends BaseController {

    @Autowired
    private BookService bookService;

    @RequestMapping("/find_book.do")
    @ResponseBody
    public ResponseResult<List<Book>> findBookByBookName(
            @RequestParam("bookName") String bookName,
            @RequestParam(value="page",required = false,defaultValue = "1") Integer page){
        ResponseResult<List<Book>> rr = new ResponseResult<>();
        List<Book> books = bookService.getBookByBookName(bookName,page);
        rr.setData(books);
        //System.out.println(books);
        return rr;
    }

    @RequestMapping("/find_book_type.do")
    @ResponseBody
    public ResponseResult<List<Book>> findBookByTye(
            @RequestParam("type") Integer type,
            @RequestParam(value="page",required = false,defaultValue = "1") Integer page){
        ResponseResult<List<Book>> rr = new ResponseResult<>();
        //System.out.println(type);
        List<Book> books = bookService.getListByType(type,page);
        rr.setData(books);
        //System.out.println(books);
        return rr;
    }

    @RequestMapping("/get_max_page.do")
    @ResponseBody
    public ResponseResult<Integer> getMaxPage(Integer type) {
        //System.out.println("**type="+type);
        Integer maxPage = bookService.getMaxPageByType(type);
        ResponseResult<Integer> rr = new ResponseResult<Integer>();
        rr.setData(maxPage);
        return rr;
    }

    @RequestMapping("/get_maxPage_bookName.do")
    @ResponseBody
    public ResponseResult<Integer> getMaxPage(String bookName) {
        //System.out.println("**bookName="+bookName);
        Integer maxPage = bookService.getMaxPageByBookName(bookName);
        ResponseResult<Integer> rr = new ResponseResult<Integer>();
        rr.setData(maxPage);
        return rr;
    }

    @RequestMapping("/add_book.do")
    @ResponseBody
    public ResponseResult<Void> AddBook(
            Book book,
            HttpServletRequest request,
            @RequestParam CommonsMultipartFile avatarFile){

        // 判断此次操作是否上传了头像
        if (!avatarFile.isEmpty()) {
            // 上传头像，并获取上传后的路径
            String avatarPath = uploadAvatar(request, avatarFile,book);
            // 把头像文件的路径封装，以写入到数据表中
            book.setImages(avatarPath);
        }

        ResponseResult<Void> rr = new ResponseResult<>();
        System.out.println("book:"+book);
        bookService.addBook(book);
        return rr;
    }

    /**
     * 上传头像
     * @param request HttpServletRequest
     * @param avatarFile CommonsMultipartFile
     * @return 成功上传后，文件保存到的路径
     * @throws UploadAvatarException 上传头像异常
     */
    private String uploadAvatar(
            HttpServletRequest request,
            CommonsMultipartFile avatarFile,
            Book book)
            throws UploadAvatarException {
        // 确定头像保存到的文件夹的路径：项目根目录下的upload文件夹
        String uploadDirPath = request.getServletContext().getRealPath("bookImg");
        // 确定头像保存到的文件夹
        File uploadDir = new File(uploadDirPath);
        // 确保文件夹存在
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }
        // 确定头像文件的扩展名，例如：aaa.bbb.ccc.jpg，所需的是.jpg
        int beginIndex = avatarFile.getOriginalFilename().lastIndexOf(".");
        String suffix = avatarFile.getOriginalFilename().substring(beginIndex);
        // 确定头像文件的文件名，必须唯一
        String fileName = book.getNumber() + suffix;
        // 确定头像保存到哪个文件
        File dest = new File(uploadDir, fileName);

        // 保存头像文件
        try {
            avatarFile.transferTo(dest);
            return "bookImg/" + fileName;
        } catch (IllegalStateException e) {
            throw new UploadAvatarException("非法状态！");
        } catch (IOException e) {
            throw new UploadAvatarException("读写出错！");
        }
    }

    @RequestMapping("/find_book1.do")
            @ResponseBody
            public ResponseResult<List<Book>> findBookByBookName1(
            @RequestParam("bookName") String bookName,
            @RequestParam(value="page",required = false,defaultValue = "1") Integer page){
        ResponseResult<List<Book>> rr = new ResponseResult<>();
        List<Book> books = bookService.getBookByBookName1(bookName,page);
        rr.setData(books);
        //System.out.println(books);
        return rr;
    }

    @RequestMapping("/get_maxPage_bookName1.do")
            @ResponseBody
            public ResponseResult<Integer> getMaxPage1(String bookName) {
        //System.out.println("**bookName="+bookName);
        Integer maxPage = bookService.getMaxPageByBookName1(bookName);
        ResponseResult<Integer> rr = new ResponseResult<Integer>();
        rr.setData(maxPage);
        return rr;
    }
}
