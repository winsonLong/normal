package cn.wonders.library.service.ex;

public class BorrowingCountOutException extends ServiceException {

    public BorrowingCountOutException() {
    }

    public BorrowingCountOutException(String message) {
        super(message);
    }

    public BorrowingCountOutException(String message, Throwable cause) {
        super(message, cause);
    }

    public BorrowingCountOutException(Throwable cause) {
        super(cause);
    }

    public BorrowingCountOutException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
