package cn.wonders.library.service;

import cn.wonders.library.entity.Book;
import cn.wonders.library.service.ex.InsertDataException;

import java.util.List;

public interface BookService {

    /**
     * 每页显示的条数
     */
    Integer COUNT_PER_PAGE = 4;

    Integer COUNT_PER_PAGE1 = 6;

    /**
     * 管理员添加图书
     * @param book
     */
    void addBook(Book book) throws InsertDataException;

    /**
     * 管理员删除图书
     * @param number
     */
    void delete(String number);

    /**
     *获取某图书类别的列表
     * @param type
     * @param page
     * @return
     */
    List<Book> getListByType(Integer type,Integer page);

    /**
     * 获取某类图书的数量
     * @param type
     * @return
     */
    Integer getCountByType(Integer type);

    /**
     * 获取某类别书籍列表的最大页数
     * @param type
     * @return
     */
    Integer getMaxPageByType(Integer type);

    /**
     * 通过图书编号查找图书
     * @param number
     * @return
     */
    Book getBookByNumber(String number);

    /**
     * 通过书名查找图书信息
     * @param bookName
     * @param page
     * @return
     */
    List<Book> getBookByBookName(String bookName,Integer page);

    /**
     * 获取模糊查询得到的书的数量
     * @param bookName
     * @return
     */
    Integer getCountByBookName(String bookName);

    /**
     * 获取模糊查询得到的列表最大页数
     * @param bookName
     * @return
     */
    Integer getMaxPageByBookName(String bookName);

    /**
     * 新增图书
     * @param book
     * @return
     */
    void insert(Book book);

    Integer getMaxPageByBookName1(String bookName);

    List<Book> getBookByBookName1(String bookName,Integer page);




}
