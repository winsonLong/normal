package cn.wonders.library.filter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HtmlAccessFilter implements Filter {

    /**
     * 允许直接访问的html文件
     */
    private List<String> accessibleHtml;


    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // 初始化方法
        System.out.println("HtmlAccessFilter.init()");
        // 穷举允许直接访问的html文件
        accessibleHtml = new ArrayList<String>();
        accessibleHtml.add("register.html");
        accessibleHtml.add("login.html");
        accessibleHtml.add("user_index.html");
        accessibleHtml.add("search.html");
        System.out.println("允许直接访问的html文件：");
        System.out.println(accessibleHtml);
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        // 执行过滤的方法
        System.out.println("HtmlAccessFilter.doFilter()");
        // 获取当前访问时的页面
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        String uri = request.getRequestURI();
        System.out.println("\turi=" + uri);
        String[] pathArray = uri.split("/");
        String file = pathArray[pathArray.length - 1];
        System.out.println("\tfile=" + file);

        // 判断当前页面是否直接放行
        if (accessibleHtml.contains(file)) {
            System.out.println("\t【放行】");
            // 继续执行过滤器链中后续的其它过滤器
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }

        System.out.println("\t【拦截】");
        // 判断是否登录
        HttpSession session = request.getSession();
        if (session.getAttribute("uid") != null) {
            // session中有uid，即已登录，则放行
            System.out.println("\t已经登录，放行！");
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }

        // 此次访问的html不在白名单中，并且，没有登录
        // 重定向到登录页
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        String loginURI = request.getContextPath() + "/web/login.html";
        System.out.println("\t未登录，重定向到：" + loginURI);
        response.sendRedirect(loginURI);
    }

    @Override
    public void destroy() {

    }
}
