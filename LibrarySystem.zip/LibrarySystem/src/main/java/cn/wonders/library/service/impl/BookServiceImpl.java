package cn.wonders.library.service.impl;

import cn.wonders.library.entity.Book;
import cn.wonders.library.mapper.BookMapper;
import cn.wonders.library.service.BookService;
import cn.wonders.library.service.ex.InsertDataException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("bookService")
public class BookServiceImpl implements BookService {

    @Autowired
    private BookMapper bookMapper;

    @Override
    public void addBook(Book book) throws InsertDataException{
        //根据新增图书的编号查询是否有该图书
        Book result = bookMapper.getBookByNumber(book.getNumber());
        if(result!=null){
            //有，增加相应的数量
            Integer newAmount = result.getAmount()+book.getAmount();
            bookMapper.changeBookAmount(newAmount,book.getNumber());
        }else {
            //没有，插入新的图书数据
            insert(book);
        }
    }

    @Override
    public void delete(String number) {
        bookMapper.delete(number);
    }

    @Override
    public List<Book> getListByType(Integer type,Integer page) {
        //如果page无效，视为page=1
        if(page==null || page<1) {
            page = 1;
        }
//        Integer sum = getCountByType(type);
//        Integer maxPage = sum/COUNT_PER_PAGE;
//        if(sum%COUNT_PER_PAGE!=0) {
//            maxPage++;
//        }
        Integer maxPage = getMaxPageByType(type);
        //如果page超出最大页数
        if(page>maxPage) {
            page = maxPage;
        }
        //执行查询
        Integer offset = (page-1)*COUNT_PER_PAGE;
        Integer count = COUNT_PER_PAGE;
        return bookMapper.getListByType(type,offset,count);
    }

    @Override
    public Integer getCountByType(Integer type) {
        return bookMapper.getCountByType(type);
    }

    @Override
    public Integer getMaxPageByType(Integer type) {
        Integer dataCount = getCountByType(type);
        Integer maxPage = (int) Math.ceil(1. * dataCount / COUNT_PER_PAGE); // 总数据量，每页数据量
        return maxPage;
    }

    @Override
    public Book getBookByNumber(String number) {
        return bookMapper.getBookByNumber(number);
    }

    @Override
    public List<Book> getBookByBookName(String bookName, Integer page) {
        //如果page无效，视为page=1
        if(page==null || page<1) {
            page = 1;
        }
        Integer maxPage = getMaxPageByBookName(bookName);
        //如果page超出最大页数
        if(page>maxPage) {
            page = maxPage;
        }
        //执行查询
        Integer offset = (page-1)*COUNT_PER_PAGE;
        Integer count = COUNT_PER_PAGE;
        return bookMapper.getBookByBookName(bookName,offset,count);
    }

    @Override
    public Integer getCountByBookName(String bookName) {
        return bookMapper.getCountByBookName(bookName);
    }

    @Override
    public Integer getMaxPageByBookName(String bookName) {
        Integer dataCount = getCountByBookName(bookName);
        Integer maxPage = (int) Math.ceil(1. * dataCount / COUNT_PER_PAGE); // 总数据量，每页数据量
        return maxPage;
    }

    @Override
    public void insert(Book book) throws InsertDataException{
        Integer rows = bookMapper.insert(book);
        if(rows!=1){
            throw new InsertDataException("新增图书时发生未知错误！");
        }
    }

    @Override
    public Integer getMaxPageByBookName1(String bookName) {
        Integer dataCount = getCountByBookName(bookName);
        Integer maxPage = (int) Math.ceil(1. * dataCount / COUNT_PER_PAGE1); // 总数据量，每页数据量
        return maxPage;
    }

    @Override
    public List<Book> getBookByBookName1(String bookName, Integer page) {
        //如果page无效，视为page=1
        if(page==null || page<1) {
            page = 1;
        }
        Integer maxPage = getMaxPageByBookName1(bookName);
        //如果page超出最大页数
        if(page>maxPage) {
            page = maxPage;
        }
        //执行查询
        Integer offset = (page-1)*COUNT_PER_PAGE1;
        Integer count = COUNT_PER_PAGE1;
        return bookMapper.getBookByBookName(bookName,offset,count);
    }

}
