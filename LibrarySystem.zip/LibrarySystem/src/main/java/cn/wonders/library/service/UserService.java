package cn.wonders.library.service;

import cn.wonders.library.entity.User;
import cn.wonders.library.service.ex.*;

import java.util.List;

public interface UserService {

    /**
     * 用户注册
     * @param user 用户信息
     * @return 成功注册的数据
     * @throws AccountConflictException 账号被占用
     * @throws InsertDataException 未知错误
     */
    User reg(User user) throws AccountConflictException,InsertDataException;

    /**
     * 用户登录
     * @param account 账号
     * @param password 密码
     * @return 成功登录的用户的数据
     * @throws PasswordNotMatchException 密码错误
     * @throws UserNotFoundException 用户不存在
     */
    User login(String account,String password) throws PasswordNotMatchException, UserNotFoundException;

    /**
     * 通过验证原密码来修改密码
     * @param uid 用户id
     * @param oldPassword 原密码
     * @param newPassword 新密码
     * @throws UserNotFoundException 尝试访问的用户的数据不存在
     * @throws PasswordNotMatchException 原密码不正确
     * @throws UpdateDataException 更新失败
     */
    void changePasswordByOldPassword(
            Integer uid, String oldPassword, String newPassword)
            throws UserNotFoundException,
            PasswordNotMatchException,
            UpdateDataException;

    /**
     * 新增用户数据
     * @param user 用户数据
     * @throws InsertDataException 插入数据失败
     */
    void insert(User user) throws InsertDataException;

    /**
     * 根据账号查询用户数据
     * @param account 账号
     * @return 与账号匹配的用户数据，如果没有匹配的数据，则返回null
     */
    User getUserByAccount(String account);

    /**
     * 根据用户id查询用户数据
     * @param uid 用户id
     * @return 与用户id匹配的用户的数据，如果没有匹配的数据，则返回null
     */
    User getUserById(Integer uid);

    /**
     * 修改密码
     * @param uid 用户id
     * @param password 新密码
     * @throws UpdateDataException 修改失败
     */
    void changePassword(Integer uid, String password) throws UpdateDataException;

    /**
     * 修改用户信息，包括姓名，性别，头像，电话，邮箱
     * @param user 被修改的用户的新信息，至少包括用户id，可修改的数据包括：姓名、性别、头像、电话、邮箱
     */
    void changeInfo(User user);

    /**
     * 获取用户信息列表
     * @return
     */
    List<User> getUserList();
}
