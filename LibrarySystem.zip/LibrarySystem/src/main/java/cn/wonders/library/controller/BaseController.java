package cn.wonders.library.controller;

import cn.wonders.library.entity.ResponseResult;
import cn.wonders.library.service.ex.*;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;

public abstract class BaseController {

    @ExceptionHandler(ServiceException.class)
    @ResponseBody
    public ResponseResult<Void> handleException(Exception e) {
        // 判断异常的类型
        if (e instanceof AccountConflictException) {
            // 账号冲突，例如新增用户时，账号已经被占用
            return new ResponseResult<Void>(401, e);
        } else if (e instanceof UserNotFoundException) {
            // 尝试访问的用户数据不存在
            return new ResponseResult<Void>(402, e);
        } else if (e instanceof PasswordNotMatchException) {
            // 验证密码时，密码不匹配
            return new ResponseResult<Void>(403, e);
        } else if (e instanceof InsertDataException) {
            // 增加数据时异常，原因未知
            return new ResponseResult<Void>(501, e);
        } else if (e instanceof UpdateDataException) {
            // 修改数据时异常，原因未知
            return new ResponseResult<Void>(502, e);
        } else if(e instanceof BorrowingCountOutException){
            return new ResponseResult<Void>(503,e);
        } else if(e instanceof UderstockException){
            return new ResponseResult<Void>(504,e);
        } else if(e instanceof RepeatBorrowingException){
            return new ResponseResult<Void>(505,e);
        }else {
            // 其它可能遗漏没有处理的异常
            return new ResponseResult<Void>(600, e);
        }
    }

    /**
     * 从Session中获取当前登录的用户的id
     * @param session
     * @return 当前登录的用户的id
     */
    protected final Integer getUidFromSession(HttpSession session) {
        return Integer.valueOf(session.getAttribute("uid").toString());
}
}
