package cn.wonders.library.service.ex;

public class UploadAvatarException extends ServiceException {

    public UploadAvatarException() {
    }

    public UploadAvatarException(String message) {
        super(message);
    }

    public UploadAvatarException(String message, Throwable cause) {
        super(message, cause);
    }

    public UploadAvatarException(Throwable cause) {
        super(cause);
    }

    public UploadAvatarException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
