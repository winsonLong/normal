package cn.wonders.library.service.impl;

import cn.wonders.library.entity.User;
import cn.wonders.library.mapper.UserMapper;
import cn.wonders.library.service.UserService;
import cn.wonders.library.service.ex.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.UUID;

@Service("userService")
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public User reg(User user) throws AccountConflictException,InsertDataException{
        //根据账号查询用数据
        User result = getUserByAccount(user.getAccount());
        //没有查找到数据
        if(result==null){
            //新增用户
            insert(user);
            //返回新增的用户的数据
            return user;
        }else{
            //查找到数据
            throw new AccountConflictException("尝试新增用户的账号("+user.getAccount()+")已经被占用");
        }
    }

    @Override
    public User login(String account, String password) throws PasswordNotMatchException,UserNotFoundException{
        //根据账号查询用数据
        User user = getUserByAccount(account);
        if (user != null) {
            // 是：账号有匹配的数据，则获取查询结果中的盐
            String salt = user.getSalt();
            // -- 对用户输入的密码执行加密
            String md5Password = getEncrpytedPassword(password, salt);
            // 判断以上加密密码与数据库的是否匹配
            if (user.getPassword().equals(md5Password)) {
                // 是：登录成功，返回查询到的对象
                return user;
            } else {
                // 否：密码错误，抛出异常：PasswordNotMatchException
                throw new PasswordNotMatchException("密码错误！");
            }
        }else{
            // 否：没有与账号匹配的数据，即账号错误，抛出异常：UserNotFoundException
            throw new UserNotFoundException("账号(" + account + ")不存在！");
        }
    }

    @Override
    public void changePasswordByOldPassword(Integer uid, String oldPassword, String newPassword) throws UserNotFoundException, PasswordNotMatchException, UpdateDataException {
        // 根据id查询用户信息
        User user = getUserById(uid);
        // 检查是否查询到用户信息
        if (user != null) {
            // 存在：获取该用户的盐值
            String salt = user.getSalt();
            // 将用户输入的密码加密
            String md5OldPassword = getEncrpytedPassword(oldPassword, salt);
            // 判断原密码是否正确
            if (user.getPassword().equals(md5OldPassword)) {
                // 正确：将新密码加密
                String md5NewPassword = getEncrpytedPassword(newPassword, salt);
                // 执行修改密码
                changePassword(uid, md5NewPassword);
            } else {
                // 错误：抛出PasswordNotMatchException
                throw new PasswordNotMatchException("原密码不正确！");
            }
        } else {
            // 不存在：抛出UserNotFoundException
            throw new UserNotFoundException("尝试访问的用户(id=" + uid + ")数据不存在！");
        }
    }

    @Override
    public void changeInfo(User user) {
        // 先检查要修改的数据是否存在
        User result = getUserById(user.getId());
        if (result != null) {
            // 用户存在，准备日志
            user.setIsManager(
                    user.getIsManager() == null ?
                            result.getIsManager() : user.getIsManager());
            // 修改信息，并获取返回值
            Integer rows = userMapper.changeInfo(user);
            // 判断操作结果
            if (rows != 1) {
                throw new UpdateDataException("修改用户信息时出现未知错误！请联系系统管理员！");
            }
        } else {
            // 用户不存在
            throw new UserNotFoundException("尝试访问的用户数据(id=" + user.getId() + ")不存在！");
        }
    }

    @Override
    public List<User> getUserList() {
        return userMapper.getUserList();
    }

    @Override
    public User getUserByAccount(String account) {
        return userMapper.getUserByAccount(account);
    }

    @Override
    public User getUserById(Integer uid) {
        return userMapper.getUserById(uid);
    }

    @Override
    public void insert(User user){
        // 加密密码
        String salt = getRandomSalt();
        String md5Password = getEncrpytedPassword(user.getPassword(), salt);
        user.setSalt(salt);
        user.setPassword(md5Password);
        // 为用户没有提交的属性设置值
        user.setBorrow(0);
        user.setIsManager(1);
        // 设置用户数据的日志
        // 执行新增用户
        Integer rows = userMapper.insert(user);
        // 判断执行结果
        if (rows != 1) {
            throw new InsertDataException("新增用户时发生未知错误！");
        }
    }

    @Override
    public void changePassword(Integer uid, String password) throws UpdateDataException{
        // 调用持久层对象的同名方法实现修改功能
        Integer rows = userMapper.changePassword(uid, password);
        // 由于是根据用户id来修改
        // 正确操作的情况下，受影响的行数一定是1
        // 所以，如果受影响行数不是1，则视出操作出错
        if (rows != 1) {
            throw new UpdateDataException("修改密码时出现未知错误！请联系系统管理员！");
        }
    }

    /**
     * 获取加密后的密码
     * @param src 原始密码
     * @param salt 盐
     * @return 加密后的密码
     * @see #md5(String)
     */
    private String getEncrpytedPassword(String src, String salt) {
        // 将原密码加密
        String s1 = md5(src);
        // 将盐加密
        String s2 = md5(salt);
        // 将2次加密结果拼接，再加密
        String s3 = s1 + s2;
        String result = md5(s3);
        // 将以上结果再加密5次
        for (int i = 0; i < 5; i++) {
            result = md5(result);
        }
        // 返回
        return result;
    }

    /**
     * 获取随机的盐值
     * @return 随机的盐值
     */
    private String getRandomSalt() {
        return UUID.randomUUID().toString().toUpperCase();
    }

    /**
     * 使用MD5算法对数据进行加密
     * @param src 原文
     * @return 密文
     */
    private String md5(String src) {
        return DigestUtils.md5DigestAsHex(src.getBytes()).toUpperCase();
    }
}
