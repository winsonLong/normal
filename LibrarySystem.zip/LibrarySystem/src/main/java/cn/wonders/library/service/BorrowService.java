package cn.wonders.library.service;

import cn.wonders.library.entity.Borrow;
import cn.wonders.library.service.ex.*;
import cn.wonders.library.vo.BorrowVO;
import cn.wonders.library.vo.BorrowingVO;
import cn.wonders.library.vo.EmailVO;
import cn.wonders.library.vo.ReturnVO;

import java.util.List;

public interface BorrowService {

    Integer COUNT_PER_PAGE = 4;

    /**
     * 借书
     */
    void addBorrow(Borrow borrow) throws InsertDataException, BorrowingCountOutException, UderstockException, RepeatBorrowingException, UpdateDataException;

    /**
     * 新增借阅的书籍
     * @param borrow
     */
    void insert(Borrow borrow) throws InsertDataException;

    /**
     * 获取uid用户已借阅未归还的书籍的数量
     * @param uid
     * @return
     */
    Integer getCountByUid(Integer uid);

    /**
     * 获取uid用户正在借阅的bid书籍的数量
     * @param uid
     * @param bid
     * @return
     */
    Integer getCountByUidAndBid(Integer uid,String bid);

    /**
     * 根据用户id查询已借阅过的书籍列表
     * @param uid
     * @param page
     * @return
     */
    List<BorrowVO> getBorrowByUid(Integer uid,Integer page);

    /**
     * 获取已借阅过的书籍的最大页数
     * @param uid
     * @return
     */
    Integer getBorrowedMaxPage(Integer uid);

    /**
     * 获取用户借阅已归还的书籍的数量
     * @param uid
     * @return
     */
    Integer getCountBorrowed(Integer uid);

    /**
     * 根据用户id查询正在借阅的书籍列表
     * @param uid
     * @param page
     * @return
     */
    List<BorrowingVO> getBorrowingByUid(Integer uid, Integer page);

    /**
     * 获取正在借阅书籍列表的最大页数
     * @param uid
     * @return
     */
    Integer getBorrowingMaxPage(Integer uid);

    /**
     * 获取用户逾期的邮件
     * */
    List<EmailVO> getEmail();

    /**
     * 根据账号查询用户正在借阅的书籍
     * @param account
     * @return
     */
    List<ReturnVO> getBorrowingListByAccount(String account);

    /**
     * 还书
     * @param uid
     * @param bid
     * @throws UderstockException
     */
    void retrunBook(Integer uid,String bid) throws UderstockException;
}
