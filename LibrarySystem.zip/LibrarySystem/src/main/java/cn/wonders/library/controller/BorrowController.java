package cn.wonders.library.controller;

import cn.wonders.library.entity.Borrow;
import cn.wonders.library.entity.ResponseResult;
import cn.wonders.library.service.BorrowService;
import cn.wonders.library.vo.BorrowVO;
import cn.wonders.library.vo.BorrowingVO;
import cn.wonders.library.vo.ReturnVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/borrow")
public class BorrowController extends BaseController {

    @Autowired
    private BorrowService borrowService;

    @RequestMapping("/borrow_book.do")
    @ResponseBody
    public ResponseResult<Void> borrowBook(HttpSession session, Borrow borrow){
        ResponseResult<Void> rr = new ResponseResult<>();
        //System.out.println("borrow:"+borrow);
        Integer uid = getUidFromSession(session);
        borrow.setUid(uid);
        borrowService.addBorrow(borrow);
        return rr;
    }

    @RequestMapping("/list_borrowed.do")
    @ResponseBody
    public ResponseResult<List<BorrowVO>> listBorrowed(
            HttpSession session,
            @RequestParam(value="page",required = false,defaultValue = "1") Integer page){
        ResponseResult<List<BorrowVO>> rr = new ResponseResult<>();
        Integer uid = getUidFromSession(session);
        List<BorrowVO> borrowVOS = borrowService.getBorrowByUid(uid,page);
        rr.setData(borrowVOS);
        return rr;
    }

    @RequestMapping("/get_borrowed_maxpage.do")
    @ResponseBody
    public ResponseResult<Integer> getMaxPage(HttpSession session){
        ResponseResult<Integer> rr = new ResponseResult<>();
        Integer uid = getUidFromSession(session);
        Integer maxPage = borrowService.getBorrowedMaxPage(uid);
        rr.setData(maxPage);
        return rr;
    }

    @RequestMapping("/list_borrowing.do")
    @ResponseBody
    public ResponseResult<List<BorrowingVO>> listBorrowing(
            HttpSession session,
            @RequestParam(value="page",required = false,defaultValue = "1") Integer page){
        ResponseResult<List<BorrowingVO>> rr = new ResponseResult<>();
        Integer uid = getUidFromSession(session);
        List<BorrowingVO> borrowingVOS = borrowService.getBorrowingByUid(uid,page);
        rr.setData(borrowingVOS);
        return rr;
    }

    @RequestMapping("/get_borrowing_maxpage.do")
    @ResponseBody
    public ResponseResult<Integer> getBorrowingListMaxPage(HttpSession session){
        ResponseResult<Integer> rr = new ResponseResult<>();
        Integer uid = getUidFromSession(session);
        Integer maxPage = borrowService.getBorrowingMaxPage(uid);
        rr.setData(maxPage);
        return rr;
    }

    @RequestMapping("/get_borrowing_account.do")
    @ResponseBody
    public ResponseResult<List<ReturnVO>> showBorrowingListByAccount(String account){
        System.out.println("account:"+account);
        ResponseResult<List<ReturnVO>> rr = new ResponseResult<>();
        List<ReturnVO> returnVOS = borrowService.getBorrowingListByAccount(account);
        rr.setData(returnVOS);
        return rr;
    }

    @RequestMapping("/return_book.do")
    @ResponseBody
    public ResponseResult<Void> handleReturnBook(Integer uid,String bid){
        ResponseResult<Void> rr = new ResponseResult<>();
        borrowService.retrunBook(uid,bid);
        return rr;
    }

}
